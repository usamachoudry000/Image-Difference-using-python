1- 1st i import libraries of numpy cv2 and matlplotlibe
2- In 2nd step i select one image file from dataset and check size.
3-In 3rd step i resize that image into 500x500 according to requiremet.
4-In 4th step i display resized image using imshow.
5-In 5th step i select n randomly (Range 1,5) patches from image and write into gallery folder. 
6-In 6th step i select m randomly (Range 1,5) patches from image and write into query folder.
7-In 7th step i read images from gallery and query folder and store into list.
8-In 8th step i use nested loop to compare and find difference of each query image with all gallery image and store into list.
9-In 9th step i show difference between images using imshow.
